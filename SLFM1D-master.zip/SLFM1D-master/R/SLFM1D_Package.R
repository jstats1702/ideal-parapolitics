#' @useDynLib SLFM1D, .registration=TRUE
#' @importFrom Rcpp sourceCpp
NULL
